using System.Text;
using MySql.Data.MySqlClient;

namespace projeto
{
    public partial class Form1 : Form
    {
        int pontuacao;

        public Form1()
        {
            InitializeComponent();
            pontuacao = 0; // inicia com 0 pontos
        }

        private void come�ar_Click(object sender, EventArgs e)
        {
            quest�o1 q1 = new quest�o1(pontuacao);
            this.Hide();
            q1.Show();
        }

        private void sair_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string connectionString = "server=localhost;User Id=root;database=placar;password=root;";
            string query = "SELECT nome, pontua�ao FROM jogador ORDER BY pontua�ao DESC LIMIT 9";

            using (MySqlConnection conn = new MySqlConnection(connectionString))
            {
                try
                {
                    conn.Open();
                    MySqlCommand cmd = new MySqlCommand(query, conn);
                    MySqlDataReader reader = cmd.ExecuteReader();

                    int posicao = 1;
                    StringBuilder resultado = new StringBuilder();

                    while (reader.Read())
                    {
                        string nome = reader["nome"].ToString();
                        int pontuacao = Convert.ToInt32(reader["pontua�ao"]);

                        resultado.AppendLine($"{posicao}�| {nome}, com {pontuacao} pontos!");
                        posicao++;
                    }

                    MessageBox.Show(resultado.ToString(), "Placar!");
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Erro ao buscar placar: " + ex.Message);
                }
            }
        }

        private void come�ar_Click_1(object sender, EventArgs e)
        {
            quest�o1 q1 = new quest�o1(pontuacao);
            this.Hide();
            q1.Show();
        }
    }
}
