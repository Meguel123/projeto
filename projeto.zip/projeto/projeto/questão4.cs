﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace projeto
{
    public partial class questão4 : Form
    {
        private int p4pontuacao;
        public questão4(int p3pontuacao)
        {
            InitializeComponent();
            this.p4pontuacao = p3pontuacao;
            label4.Hide();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            pontuação q2 = new pontuação(p4pontuacao);
            this.Hide();
            q2.Show();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            pontuação q2 = new pontuação(p4pontuacao);
            this.Hide();
            q2.Show();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            pontuação q2 = new pontuação(p4pontuacao);
            this.Hide();
            q2.Show();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            pontuação q2 = new pontuação(p4pontuacao);
            this.Hide();
            q2.Show();
        }

        private void questão4_Load(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {
           
            label4.Show();
        }

        private void label3_Click(object sender, EventArgs e)
        {
          
        }

        private void label4_Click(object sender, EventArgs e)
        {
            p4pontuacao += 10;
            questão5 q2 = new questão5(p4pontuacao);
            this.Hide();
            q2.Show();
        }
    }
}
