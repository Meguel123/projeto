﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace projeto
{
    public partial class questão6 : Form
    {
        private int p6pontuacao;
        public questão6(int p5pontuacao)
        {
            InitializeComponent();
            this.p6pontuacao = p5pontuacao;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            pontuação q2 = new pontuação(p6pontuacao);
            this.Hide();
            q2.Show();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            pontuação q2 = new pontuação(p6pontuacao);
            this.Hide();
            q2.Show();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            pontuação q2 = new pontuação(p6pontuacao);
            this.Hide();
            q2.Show();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            pontuação q2 = new pontuação(p6pontuacao);
            this.Hide();
            q2.Show();
        }

        private void label2_Click(object sender, EventArgs e)
        {
            p6pontuacao += 10;
            questão7 q2 = new questão7(p6pontuacao);
            this.Hide();
            q2.Show();
        }
    }
}
