﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;
namespace projeto
{
    public partial class placar : Form
    {
        public placar()
        {
            InitializeComponent();
            dataGridView1.Hide();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Form1 form1 = new Form1();
            this.Hide();
            form1.ShowDialog();

        }

        private void button2_Click(object sender, EventArgs e)
        {
            string connectionString = "server=localhost;User Id=root;database=placar;password=root;";
            string query = "SELECT nome, pontuaçao FROM jogador ORDER BY pontuaçao DESC LIMIT 9";

            using (MySqlConnection conn = new MySqlConnection(connectionString))
            {
                try
                {
                    conn.Open();
                    MySqlCommand cmd = new MySqlCommand(query, conn);
                    MySqlDataReader reader = cmd.ExecuteReader();

                    int posicao = 1;
                    StringBuilder resultado = new StringBuilder();

                    while (reader.Read())
                    {
                        string nome = reader["nome"].ToString();
                        int pontuacao = Convert.ToInt32(reader["pontuaçao"]);

                        resultado.AppendLine($"{posicao}°| {nome}, com {pontuacao} pontos!");
                        posicao++;
                    }

                    MessageBox.Show(resultado.ToString(), "Placar!");
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Erro ao buscar placar: " + ex.Message);
                }
            }
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
    }
}
