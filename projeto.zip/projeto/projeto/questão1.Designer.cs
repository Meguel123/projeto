﻿namespace projeto
{
    partial class questão1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label1 = new Label();
            button1 = new Button();
            button2 = new Button();
            button3 = new Button();
            button4 = new Button();
            label2 = new Label();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Segoe UI", 25F);
            label1.Location = new Point(12, 9);
            label1.Name = "label1";
            label1.Size = new Size(694, 46);
            label1.TabIndex = 0;
            label1.Text = "1. Como Jack Estripador matava suas vitimas?";
            label1.Click += label1_Click;
            // 
            // button1
            // 
            button1.Location = new Point(84, 136);
            button1.Name = "button1";
            button1.Size = new Size(232, 85);
            button1.TabIndex = 1;
            button1.Text = "multiladas";
            button1.UseVisualStyleBackColor = true;
            button1.Click += button1_Click;
            // 
            // button2
            // 
            button2.Location = new Point(463, 136);
            button2.Name = "button2";
            button2.Size = new Size(232, 85);
            button2.TabIndex = 2;
            button2.Text = "afogadas";
            button2.UseVisualStyleBackColor = true;
            button2.Click += button2_Click;
            // 
            // button3
            // 
            button3.Location = new Point(84, 281);
            button3.Name = "button3";
            button3.Size = new Size(232, 85);
            button3.TabIndex = 3;
            button3.Text = "incendiadas";
            button3.UseVisualStyleBackColor = true;
            button3.Click += button3_Click;
            // 
            // button4
            // 
            button4.Location = new Point(463, 272);
            button4.Name = "button4";
            button4.Size = new Size(232, 85);
            button4.TabIndex = 4;
            button4.Text = "envenenadas";
            button4.UseVisualStyleBackColor = true;
            button4.Click += button4_Click;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(574, 426);
            label2.Name = "label2";
            label2.Size = new Size(215, 15);
            label2.TabIndex = 5;
            label2.Text = "Todos direitos reservados © 2MD2 2025";
            label2.Click += label2_Click;
            // 
            // questão1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(label2);
            Controls.Add(button4);
            Controls.Add(button3);
            Controls.Add(button2);
            Controls.Add(button1);
            Controls.Add(label1);
            Name = "questão1";
            Text = "questão1";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private Button button1;
        private Button button2;
        private Button button3;
        private Button button4;
        private Label label2;
    }
}