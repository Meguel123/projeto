﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static Org.BouncyCastle.Asn1.Cmp.Challenge;

namespace projeto
{
    public partial class questao9 : Form
    {
        private int p9pontuacao;
        public questao9(int p8pontuacao)
        {
            InitializeComponent();
            this.p9pontuacao = p8pontuacao;
          
            label2.Hide();
        }
        private void button1_Click(object sender, EventArgs e)
        {
            Random random = new Random();
            int numeroAleatorio = random.Next(1, 6);

            if (numeroAleatorio == 1)
            {

                label3.Text = "Tem certeza?";
                label3.Show();
            }

            else if (numeroAleatorio == 2)
            {
                label3.Text = "Tem certeza absoluta?";
                label3.Show();
            }

            else if (numeroAleatorio == 3)
            {
                label3.Text = "isso tá indo longe demais";
                label3.Show();
            }

            else if (numeroAleatorio == 4)
            {
                label3.Text = "PARE VOCÊ NÃO VAI GANHAR";
                label3.Show();
            }

            else if (numeroAleatorio == 5)
            {
                label3.Text = "desista dessa resposta";
                label3.Show();
            }

            else if (numeroAleatorio == 6)
            {
                label3.Text = "você realmente quer tentar isso";
                label3.Show();
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            pontuação q2 = new pontuação(p9pontuacao);
            this.Hide();
            q2.Show();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            pontuação q2 = new pontuação(p9pontuacao);
            this.Hide();
            q2.Show();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            pontuação q2 = new pontuação(p9pontuacao);
            this.Hide();
            q2.Show();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {
            questao10 q2 = new questao10(p9pontuacao);
            this.Hide();
            q2.Show();


        }

        private void label4_Click(object sender, EventArgs e)
        {
            label2.Show();
        }
    }
}
