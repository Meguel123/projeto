﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace projeto
{
    public partial class questão3 : Form
    {
        private int p3pontuacao;
        public questão3(int p1pontuacao)
        {
            InitializeComponent();
            p3pontuacao = p1pontuacao;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            pontuação q2 = new pontuação(p3pontuacao);
            this.Hide();
            q2.Show();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            pontuação q2 = new pontuação(p3pontuacao);
            this.Hide();
            q2.Show();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            pontuação q2 = new pontuação(p3pontuacao);
            this.Hide();
            q2.Show();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            pontuação q2 = new pontuação(p3pontuacao);
            this.Hide();
            q2.Show();
        }

        private void questão3_Load(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {
            p3pontuacao += 10;
            questão4 q2 = new questão4(p3pontuacao);
            this.Hide();
            q2.Show();
        }
    }
}
