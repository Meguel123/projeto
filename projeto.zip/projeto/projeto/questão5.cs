﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace projeto
{
    public partial class questão5 : Form
    {
        private int p5pontuacao;
        public questão5(int p4pontuacao)
        {
            InitializeComponent();
            this.p5pontuacao = p4pontuacao;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            pontuação q2 = new pontuação(p5pontuacao);
            this.Hide();
            q2.Show();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            pontuação q2 = new pontuação(p5pontuacao);
            this.Hide();
            q2.Show();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            pontuação q2 = new pontuação(p5pontuacao);
            this.Hide();
            q2.Show();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            pontuação q2 = new pontuação(p5pontuacao);
            this.Hide();
            q2.Show();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void questão5_Load(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {
            p5pontuacao += 10;
            questão6 q2 = new questão6(p5pontuacao);
            this.Hide();
            q2.Show();
        }
    }
}
