﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace projeto
{
    public partial class questao8 : Form
    {
        private int p8pontuacao;
        public questao8(int p7pontuacao)
        {
            InitializeComponent();
            this.p8pontuacao = p7pontuacao;
            button5.Hide();
            label3.Hide();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            pontuação q2 = new pontuação(p8pontuacao);
            this.Hide();
            q2.Show();

        }

        private void button2_Click(object sender, EventArgs e)
        {
            pontuação q2 = new pontuação(p8pontuacao);
            this.Hide();
            q2.Show();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            pontuação q2 = new pontuação(p8pontuacao);
            this.Hide();
            q2.Show();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            pontuação q2 = new pontuação(p8pontuacao);
            this.Hide();
            q2.Show();
        }

        private void label2_Click(object sender, EventArgs e)
        {
            button5.Show();
            label3.Show();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            pontuação q2 = new pontuação(p8pontuacao);
            this.Hide();
            q2.Show();
        }

        private void label3_Click(object sender, EventArgs e)
        {
            p8pontuacao += 10;
            questao9 q2 = new questao9(p8pontuacao);
            this.Hide();
            q2.Show();
        }
    }
}
