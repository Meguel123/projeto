﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;
namespace projeto
{
    public partial class pontuação : Form
    {
        private int p2pontuacao;
        public pontuação(int p1pontuacao)
        {
            InitializeComponent();
            p2pontuacao = p1pontuacao;
        }

        private void label2_Click(object sender, EventArgs e)
        {
            label2.Text = p2pontuacao.ToString();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            label2.Text = "meus parabens eu acho " + textBox1.Text + " Sua pontuação é "+ p2pontuacao.ToString();
            string conexao = "Server=localhost;Database=placar;Uid=root;Pwd=root;";
            string query = "insert into jogador (nome, pontuaçao) values (@nome , @pontuaçao)";

            using (MySqlConnection conn = new MySqlConnection(conexao))
            {
                try
                {
                    conn.Open();
                    MySqlCommand cmd = new MySqlCommand(query, conn);
                    cmd.Parameters.AddWithValue("@nome", textBox1.Text);
                    cmd.Parameters.AddWithValue("@pontuaçao", p2pontuacao);
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Cadastro realizado com sucesso!!!");
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Erro: " + ex.Message);
                }


            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Form1 form1 = new Form1();
            this.Hide();
            form1.Show();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string connectionString = "server=localhost;User Id=root;database=placar;password=root;";
            string query = "SELECT nome, pontuaçao FROM jogador ORDER BY pontuaçao DESC LIMIT 9";

            using (MySqlConnection conn = new MySqlConnection(connectionString))
            {
                try
                {
                    conn.Open();
                    MySqlCommand cmd = new MySqlCommand(query, conn);
                    MySqlDataReader reader = cmd.ExecuteReader();

                    int posicao = 1;
                    StringBuilder resultado = new StringBuilder();

                    while (reader.Read())
                    {
                        string nome = reader["nome"].ToString();
                        int pontuacao = Convert.ToInt32(reader["pontuaçao"]);

                        resultado.AppendLine($"{posicao}°| {nome}, com {pontuacao} pontos!");
                        posicao++;
                    }

                    MessageBox.Show(resultado.ToString(), "Placar!");
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Erro ao buscar placar: " + ex.Message);
                }
            }
        }
    }
}
