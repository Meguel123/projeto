﻿namespace projeto
{
    partial class questão7
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            button1 = new Button();
            button2 = new Button();
            button3 = new Button();
            button4 = new Button();
            label1 = new Label();
            label2 = new Label();
            button5 = new Button();
            label3 = new Label();
            SuspendLayout();
            // 
            // button1
            // 
            button1.Location = new Point(94, 154);
            button1.Name = "button1";
            button1.Size = new Size(232, 85);
            button1.TabIndex = 0;
            button1.Text = "Sasquash";
            button1.UseVisualStyleBackColor = true;
            button1.Click += button1_Click;
            // 
            // button2
            // 
            button2.Location = new Point(452, 154);
            button2.Name = "button2";
            button2.Size = new Size(232, 85);
            button2.TabIndex = 1;
            button2.Text = "Sasquash";
            button2.UseVisualStyleBackColor = true;
            button2.Click += button2_Click;
            // 
            // button3
            // 
            button3.Location = new Point(94, 295);
            button3.Name = "button3";
            button3.Size = new Size(232, 85);
            button3.TabIndex = 2;
            button3.Text = "Sasquash";
            button3.UseVisualStyleBackColor = true;
            button3.Click += button3_Click;
            // 
            // button4
            // 
            button4.Location = new Point(452, 295);
            button4.Name = "button4";
            button4.Size = new Size(232, 85);
            button4.TabIndex = 3;
            button4.Text = "Sasquash";
            button4.UseVisualStyleBackColor = true;
            button4.Click += button4_Click;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Segoe UI", 24F);
            label1.Location = new Point(12, 9);
            label1.Name = "label1";
            label1.Size = new Size(619, 45);
            label1.TabIndex = 4;
            label1.Text = "7. Qual o outro nome dado ao pé grande?";
            label1.Click += label1_Click;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Segoe UI", 24F);
            label2.Location = new Point(234, 9);
            label2.Name = "label2";
            label2.Size = new Size(102, 45);
            label2.TabIndex = 5;
            label2.Text = "nome";
            label2.Click += label2_Click;
            // 
            // button5
            // 
            button5.Location = new Point(94, 154);
            button5.Name = "button5";
            button5.Size = new Size(232, 85);
            button5.TabIndex = 6;
            button5.Text = "Sasquash";
            button5.UseVisualStyleBackColor = true;
            button5.Click += button5_Click;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(353, 101);
            label3.Name = "label3";
            label3.Size = new Size(76, 15);
            label3.TabIndex = 7;
            label3.Text = "tem certeza ?";
            label3.Click += label3_Click;
            // 
            // questão7
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(label3);
            Controls.Add(button5);
            Controls.Add(label2);
            Controls.Add(label1);
            Controls.Add(button4);
            Controls.Add(button3);
            Controls.Add(button2);
            Controls.Add(button1);
            Name = "questão7";
            Text = "questão7";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Button button1;
        private Button button2;
        private Button button3;
        private Button button4;
        private Label label1;
        private Label label2;
        private Button button5;
        private Label label3;
    }
}