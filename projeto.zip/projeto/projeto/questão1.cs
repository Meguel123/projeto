﻿namespace projeto
{
    public partial class questão1 : Form
    {
        private int ppontuacao;


        public questão1(int pontuacao)
        {
            InitializeComponent();
            ppontuacao = pontuacao;
        }

        private void button1_Click(object sender, EventArgs e)
        {
               // Exemplo: se acertou
            ppontuacao += 10;

            questao2 q2 = new questao2(ppontuacao);
            this.Hide();
            q2.Show();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            // Exemplo: se errou
            pontuação q2 = new pontuação(ppontuacao);
            this.Hide();
            q2.Show();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            pontuação q2 = new pontuação(ppontuacao);
            this.Hide();
            q2.Show();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            pontuação q2 = new pontuação(ppontuacao);
            this.Hide();
            q2.Show();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }
    }
}
